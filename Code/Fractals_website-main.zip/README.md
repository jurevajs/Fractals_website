# Fractals_website
A website for customizing fractals

Started making a website for customizing fractals, for my matura project. Will keep uploading files until its done.

git add (ime)
git commit -m "komentar"
git push (kam) (kaj)
